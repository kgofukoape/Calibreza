'use client';

import React from 'react';
import Link from 'next/link';
import Navbar from '@/components/layout/Navbar';

const mockListings = [
  { id: 1, title: 'Glock 17 Gen 5', price: '12,500', loc: 'GP', cat: 'Pistols' },
  { id: 2, title: 'Folding Karambit', price: '1,200', loc: 'WC', cat: 'Knives' },
  { id: 3, title: '9mm PMP Ammo', price: '450', loc: 'KZN', cat: 'Ammo' },
  { id: 4, title: 'CZ P-07 Kadet', price: '9,800', loc: 'LP', cat: 'Pistols' },
  { id: 5, title: 'Leather OWB Holster', price: '850', loc: 'EC', cat: 'Gear' },
  { id: 6, title: 'Tikka T3x 6.5 CM', price: '24,000', loc: 'NW', cat: 'Rifles' },
  { id: 7, title: 'Gas Blowback Pistol', price: '3,200', loc: 'FS', cat: 'Airsoft' },
  { id: 8, title: 'Buck Fixed Blade', price: '2,100', loc: 'NC', cat: 'Knives' },
];

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#0D0F13] text-[#F0EDE8] overflow-x-hidden flex flex-col">
      <Navbar />

      {/* 1. TOP LEADERBOARD AD */}
      <div className="w-full flex justify-center pt-6 pb-2 px-4">
        <div className="w-full max-w-[970px] h-[110px] bg-[#12141a] border border-white/5 flex items-center justify-center relative">
          <span className="text-[10px] text-[#5A5E69] uppercase tracking-[0.4em] font-bold">Top Leaderboard Ad Space</span>
          <div className="absolute inset-0 border border-dashed border-white/10 opacity-20"></div>
        </div>
      </div>

      <main className="relative flex-1 w-full">

        {/* 2. SIDEBAR ADS — hero area only, ends before reel with gap */}
        <aside className="hidden xl:block absolute left-4 top-[-118px] w-[220px] h-[560px] bg-[#12141a] border border-white/5 z-0 mb-6">
          <div className="h-full w-full flex flex-col items-center justify-center p-4 text-center">
            <span className="text-[9px] text-[#5A5E69] uppercase tracking-widest mb-4">Advertisement</span>
            <div className="flex-1 w-full border border-dashed border-white/10 flex items-center justify-center text-[10px] text-[#3A3E49] leading-relaxed font-bold">
              180 x 570
            </div>
          </div>
        </aside>

        <aside className="hidden xl:block absolute right-4 top-[-118px] w-[220px] h-[560px] bg-[#12141a] border border-white/5 z-0">
          <div className="h-full w-full flex flex-col items-center justify-center p-4 text-center">
            <span className="text-[9px] text-[#5A5E69] uppercase tracking-widest mb-4">Advertisement</span>
            <div className="flex-1 w-full border border-dashed border-white/10 flex items-center justify-center text-[10px] text-[#3A3E49] leading-relaxed font-bold">
              180 x 570
            </div>
          </div>
        </aside>

        {/* 3. HERO CONTENT */}
        <section className="relative pt-6 md:pt-10 pb-8 px-6 text-center max-w-[1050px] mx-auto z-10">
          <h1 style={{fontFamily:"'Barlow Condensed', sans-serif"}} className="text-[40px] sm:text-[60px] md:text-[80px] lg:text-[100px] font-black uppercase tracking-tighter leading-[0.85] mb-8 md:mb-12">
            SOUTH AFRICA&apos;S <br className="hidden sm:block" />
            <span className="text-[#C9922A]">PREMIER FIREARMS</span> <br />
            CLASSIFIEDS
          </h1>

          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-10 md:mb-12">
            <Link href="/browse" className="bg-[#C9922A] text-black px-10 py-4 font-black uppercase tracking-widest text-[14px] md:text-[16px] hover:brightness-110 transition-all shadow-[0_0_30px_rgba(201,146,42,0.2)]">
              BROWSE LISTINGS
            </Link>
            <Link href="/sell" className="border border-white/10 text-white px-10 py-4 font-black uppercase tracking-widest text-[14px] md:text-[16px] hover:bg-white/5 transition-all">
              POST FREE LISTING
            </Link>
          </div>

          {/* 4. THE REEL — full width, untouched */}
          <div className="relative w-screen left-1/2 right-1/2 -ml-[50vw] py-8 border-y border-white/5 bg-[#12141a]/50">
            <div className="flex gap-4 animate-scroll whitespace-nowrap px-4">
              {[...mockListings, ...mockListings].map((item, idx) => (
                <div key={idx} className="min-w-[190px] md:min-w-[210px] bg-[#191C23] border border-white/5 p-3 rounded-sm shrink-0 text-left hover:border-[#C9922A]/40 transition-colors">
                  <div className="aspect-[4/3] bg-[#0D0F13] mb-3 relative overflow-hidden">
                    <div className="absolute top-2 left-2 bg-[#C9922A] text-black text-[8px] font-black px-1.5 py-0.5 uppercase tracking-tighter z-10">{item.cat}</div>
                  </div>
                  <h4 className="font-bold text-[12px] uppercase mb-1 truncate text-[#F0EDE8]">{item.title}</h4>
                  <p className="text-[#C9922A] font-black text-md mb-1">R {item.price}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 5. BROWSE BY CATEGORY */}
        <section className="max-w-[1400px] mx-auto px-6 py-24">
          <div className="text-center mb-20">
            <h2 style={{fontFamily:"'Barlow Condensed', sans-serif"}} className="text-4xl md:text-7xl font-black uppercase tracking-tight mb-4 text-[#F0EDE8]">
              Browse By <span className="text-[#C9922A]">Category</span>
            </h2>
            <p className="text-[#8A8E99] text-[12px] md:text-[14px] uppercase tracking-[0.3em] font-bold px-4">
              Explore thousands of listings across all firearm categories
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 md:gap-4">
            {[
              { n: 'Pistols', c: '1,240', i: '🎯' },
              { n: 'Rifles', c: '1,820', i: '🔭' },
              { n: 'Shotguns', c: '540', i: '♾️' },
              { n: 'Revolvers', c: '310', i: '🎡' },
              { n: 'Air Guns', c: '420', i: '💨' },
              { n: 'Airsoft Guns', c: '280', i: '⚡' },
              { n: 'Holsters & Carry', c: '950', i: '∪' },
              { n: 'Mags & Loaders', c: '1,420', i: '⋮' },
              { n: 'Accessories', c: '2,680', i: '🛍️' },
              { n: 'Ammunition', c: '850', i: '⧊' },
              { n: 'Reloading', c: '1,120', i: '🔧' },
              { n: 'Knives & Blades', c: '670', i: '🖋️' },
              { n: 'Services', c: '140', i: '🏠' },
              { n: 'Clubs & Ranges', c: '215', i: '⊕' },
              { n: 'Wanted', c: '85', i: '🔍' },
            ].map((cat) => (
              <Link
                key={cat.n}
                href={`/browse/${cat.n.toLowerCase().replace(/ & /g, '-')}`}
                className="bg-[#13151A] border border-white/5 p-6 md:p-10 flex flex-col items-center group hover:border-[#C9922A]/30 transition-all rounded-sm text-center"
              >
                <span className="text-xl md:text-2xl mb-4 md:mb-6 opacity-60 group-hover:opacity-100 transition-opacity">{cat.i}</span>
                <h3 className="font-bold uppercase tracking-widest text-[11px] md:text-[13px] mb-1">{cat.n}</h3>
                <p className="text-[9px] text-[#8A8E99] uppercase tracking-tighter">{cat.c} listings</p>
              </Link>
            ))}
          </div>
        </section>

        {/* 6. WHY CHOOSE SECTION */}
        <section className="max-w-[1400px] mx-auto px-6 py-24 border-t border-white/5">
          <div className="text-center mb-16">
            <h2 style={{fontFamily:"'Barlow Condensed', sans-serif"}} className="text-5xl md:text-6xl font-black uppercase tracking-tight mb-4">
              Why Choose <span className="text-[#C9922A]">Gun X?</span>
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { t: 'Verified Sellers', d: 'Every dealer and private seller goes through identity verification.', i: '🛡️' },
              { t: 'Provincial Search', d: 'Find firearms close to home. Filter by province and city.', i: '📍' },
              { t: 'FCA Compliant', d: 'All listings comply with the Firearms Control Act.', i: '📋' },
            ].map(item => (
              <div key={item.t} className="bg-[#13151A] p-8 md:p-10 border border-white/5 rounded-sm">
                <div className="w-12 h-12 bg-[#191C23] border border-[#C9922A]/20 flex items-center justify-center rounded-sm mb-6 text-xl">{item.i}</div>
                <h3 className="text-xl font-bold uppercase tracking-tight mb-4">{item.t}</h3>
                <p className="text-[#8A8E99] text-sm leading-relaxed">{item.d}</p>
              </div>
            ))}
          </div>
        </section>

        {/* 7. DEALERSHIP SECTION */}
        <section className="max-w-[1400px] mx-auto px-6 py-24">
          <div className="bg-[#13151A] border border-[#C9922A]/20 p-8 md:p-20 rounded-sm flex flex-col lg:flex-row justify-between items-center gap-12">
            <div className="max-w-2xl text-center lg:text-left">
              <h2 style={{fontFamily:"'Barlow Condensed', sans-serif"}} className="text-4xl md:text-7xl font-black uppercase leading-none mb-6">
                Grow Your <span className="text-[#C9922A]">Dealership</span> Online.
              </h2>
              <p className="text-[#8A8E99] text-base md:text-lg mb-10">
                List your inventory and reach thousands of buyers across SA.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[11px] md:text-sm font-bold uppercase tracking-wider text-[#F0EDE8]">
                {['Dedicated storefront', 'Unlimited listings', 'Priority search', 'Lead analytics'].map(li => (
                  <div key={li} className="flex items-center gap-3">
                    <span className="text-[#C9922A]">✓</span> {li}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-4 w-full sm:w-auto">
              <Link href="/dealer/apply" className="bg-[#C9922A] text-black px-10 py-4 font-black uppercase tracking-widest text-[14px] hover:brightness-110 transition-all text-center">
                Apply for Dealer Account
              </Link>
            </div>
          </div>
        </section>

        {/* FOOTER */}
        <footer className="bg-[#08090B] border-t border-white/5 pt-16 pb-8 px-6">
          <div className="max-w-[1280px] mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
              <div className="md:col-span-1">
                <span style={{fontFamily:"'Barlow Condensed', sans-serif"}} className="text-3xl font-black text-[#F0EDE8] leading-none tracking-tighter uppercase block mb-6">
                  GUN <span className="text-[#C9922A]">X</span>
                </span>
                <p className="text-[14px] text-[#8A8E99] leading-relaxed mb-6">
                  South Africa's cleanest classified portal for legal firearms. Connecting licensed dealers and private sellers with buyers across all nine provinces.
                </p>
                <div className="flex items-center gap-3 text-[11px] text-[#8A8E99] font-bold">
                  <span>FCA Compliant</span><span>·</span><span>POPI Act Registered</span>
                </div>
              </div>
              <div>
                <h3 style={{fontFamily:"'Barlow Condensed', sans-serif"}} className="text-[14px] font-black uppercase tracking-widest text-[#F0EDE8] mb-6">Browse</h3>
                <ul className="space-y-3">
                  {['Pistols','Rifles','Shotguns','Revolvers','Air Guns','Airsoft Guns','Holsters','Magazines','Accessories','Ammunition','Reloading','Sport Shooting'].map(item => (
                    <li key={item}>
                      <Link href={`/${item.toLowerCase().replace(/ /g,'-')}`} className="text-[14px] text-[#8A8E99] hover:text-[#C9922A] transition-colors">{item}</Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 style={{fontFamily:"'Barlow Condensed', sans-serif"}} className="text-[14px] font-black uppercase tracking-widest text-[#F0EDE8] mb-6">Platform</h3>
                <ul className="space-y-3">
                  {[['How it Works','/how-it-works'],['Dealer Directory','/dealers'],['Post a Listing','/sell'],['Dealer Plans','/dealer/pricing'],['Price Guide','/price-guide']].map(([label,href]) => (
                    <li key={label}>
                      <Link href={href} className="text-[14px] text-[#8A8E99] hover:text-[#C9922A] transition-colors">{label}</Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 style={{fontFamily:"'Barlow Condensed', sans-serif"}} className="text-[14px] font-black uppercase tracking-widest text-[#F0EDE8] mb-6">Company</h3>
                <ul className="space-y-3">
                  {[['About Us','/about'],['Contact','/contact'],['FAQs','/faqs'],['Blog','/blog'],['Report a Listing','/report']].map(([label,href]) => (
                    <li key={label}>
                      <Link href={href} className="text-[14px] text-[#8A8E99] hover:text-[#C9922A] transition-colors">{label}</Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-[13px] text-[#8A8E99]">© 2026 Gun X — All rights reserved</p>
              <div className="flex items-center gap-6 text-[13px] text-[#8A8E99]">
                {[['Terms of Use','/terms'],['Privacy Policy','/privacy'],['POPI Act','/popi'],['Legal Disclaimer','/legal']].map(([label,href]) => (
                  <Link key={label} href={href} className="hover:text-[#C9922A] transition-colors">{label}</Link>
                ))}
              </div>
            </div>
          </div>
        </footer>
      </main>

      <style jsx global>{`
        @keyframes scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(calc(-190px * 8 - 1rem * 8)); }
        }
        @media (min-width: 768px) {
          @keyframes scroll {
            0% { transform: translateX(0); }
            100% { transform: translateX(calc(-210px * 8 - 1rem * 8)); }
          }
        }
        .animate-scroll { animation: scroll 40s linear infinite; }
        .animate-scroll:hover { animation-play-state: paused; }
      `}</style>
    </div>
  );
}